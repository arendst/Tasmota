/*
  bg-BG.h - localization for Bulgaria - Bulgarian for Sonoff-Tasmota

  Copyright (C) 2018  Theo Arends

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _LANGUAGE_BG_BG_H_
#define _LANGUAGE_BG_BG_H_

//STB mod
#define D_JSON_MOISTURE "Moisture"
#define D_JSON_DISTANCE "Distance"
#define D_CONFIGURE_PCF8574 "Configure PCF8574"
#define D_CMND_COUNTERDEVIDER "CounterDevider"
#define D_CMND_MQTTENABLE "MqttEnable"
#define D_SENSOR_DEEPSLEEP "DeepSleep Switch"
#define D_CMND_OPEN "shutteropen"
#define D_CMND_CLOSE "shutterclose"
#define D_CMND_STOP "shutterstop"
#define D_CMND_POSITION "shutterposition"
#define D_CMND_OPENTIME "shutteropenduration"
#define D_CMND_CLOSETIME "shuttercloseduration"
#define D_CMND_SHUTTERRELAY "shutterrelay"
#define D_OPEN "Open"
#define D_CLOSE "Close"
#define D_SHUTTER "SHUTTER"
#define D_CMND_INTERLOCKMASK "INTERLOCKMASK"
#define D_CMND_SET50PERCENT "shutter50percent"
#define D_CMND_SHUTTERSETCLOSE "shuttersetclose"
//end

/*************************** ATTENTION *******************************\
 *
 * Due to memory constraints only UTF-8 is supported.
 * To save code space keep text as short as possible.
 * Time and Date provided by SDK can not be localized (yet).
 * Use online command StateText to translate ON, OFF, HOLD and TOGGLE.
 * Use online command Prefix to translate cmnd, stat and tele.
 *
 * Updated until v6.0.0a
\*********************************************************************/

//#define LANGUAGE_MODULE_NAME         // Enable to display "Module Generic" (ie Spanish), Disable to display "Generic Module" (ie English)

#define LANGUAGE_LCID 1026
// HTML (ISO 639-1) Language Code
#define D_HTML_LANGUAGE "bg"

// "2017-03-07T11:08:02" - ISO8601:2004
#define D_YEAR_MONTH_SEPARATOR "-"
#define D_MONTH_DAY_SEPARATOR "-"
#define D_DATE_TIME_SEPARATOR "T"
#define D_HOUR_MINUTE_SEPARATOR ":"
#define D_MINUTE_SECOND_SEPARATOR ":"

#define D_DAY3LIST "НедПонВтрСрдЧетПетСъб"
#define D_MONTH3LIST "ЯнуФевМарАпрМайЮниЮлиАвгСепОктНоеДек"

// Non JSON decimal separator
#define D_DECIMAL_SEPARATOR ","

// Common
#define D_ADMIN "Admin"
#define D_AIR_QUALITY "Качество на въздуха"
#define D_AP "Точка за достъп"                    // Access Point
#define D_AS "като"
#define D_AUTO "АВТОМАТИЧНО"
#define D_BLINK "Мигане вкл."
#define D_BLINKOFF "Мигане изкл."
#define D_BOOT_COUNT "Брой на стартиранията"
#define D_BRIGHTLIGHT "Яркост"
#define D_BUTTON "Бутон"
#define D_BY "от"                    // Written by me
#define D_BYTES "Байта"
#define D_CELSIUS "Целзий"
#define D_CO2 "Въглероден диоксид"
#define D_CODE "код"                // Button code
#define D_COLDLIGHT "Хладна"
#define D_COMMAND "Команда"
#define D_CONNECTED "Свързан"
#define D_COUNT "Брой"
#define D_COUNTER "Брояч"
#define D_CURRENT "Ток"          // As in Voltage and Current
#define D_DATA "Данни"
#define D_DARKLIGHT "Тъмна"
#define D_DEBUG "Дебъгване"
#define D_DISABLED "Деактивиран"
#define D_DISTANCE "Разстояние"
#define D_DNS_SERVER "DNS Сървър"
#define D_DONE "Изпълнено"
#define D_DST_TIME "DST"
#define D_ECO2 "eCO2"
#define D_EMULATION "Емулация"
#define D_ENABLED "Активиран"
#define D_ERASE "Изтриване"
#define D_ERROR "Грешка"
#define D_FAHRENHEIT "Фаренхайт"
#define D_FAILED "Неуспешно"
#define D_FALLBACK "Помощен"
#define D_FALLBACK_TOPIC "Помощен топик"
#define D_FALSE "Невярно"
#define D_FILE "Файл"
#define D_FREE_MEMORY "Свободна памет"
#define D_FREQUENCY "Честота"
#define D_GAS "Газ"
#define D_GATEWAY "Шлюз"
#define D_GROUP "Група"
#define D_HOST "Хост"
#define D_HOSTNAME "Име на хоста"
#define D_HUMIDITY "Влажност"
#define D_ILLUMINANCE "Осветеност"
#define D_IMMEDIATE "Моментен"      // Button immediate
#define D_INDEX "Индекс"
#define D_INFO "Информация"
#define D_INFRARED "Инфрачервен"
#define D_INITIALIZED "Инициализирано"
#define D_IP_ADDRESS "IP адрес"
#define D_LIGHT "Светлина"
#define D_LWT "LWT"
#define D_MODULE "Модул"
#define D_MQTT "MQTT"
#define D_MULTI_PRESS "множествено натискане"
#define D_NOISE "Шум"
#define D_NONE "Няма"
#define D_OFF "Изкл."
#define D_OFFLINE "Офлайн"
#define D_OK "Ок"
#define D_ON "Вкл."
#define D_ONLINE "Онлайн"
#define D_PASSWORD "Парола"
#define D_PORT "Порт"
#define D_POWER_FACTOR "Фактор на мощността"
#define D_POWERUSAGE "Мощност"
#define D_POWERUSAGE_ACTIVE "Активна мощност"
#define D_POWERUSAGE_APPARENT "Пълна мощност"
#define D_POWERUSAGE_REACTIVE "Реактивна мощност"
#define D_PRESSURE "Налягане"
#define D_PRESSUREATSEALEVEL "Налягане на морското ниво"
#define D_PROGRAM_FLASH_SIZE "Размер на флаш паметта за програми"
#define D_PROGRAM_SIZE "Размер на програмата"
#define D_PROJECT "Проект"
#define D_RECEIVED "Получено"
#define D_RESTART "Рестарт"
#define D_RESTARTING "Рестартиране"
#define D_RESTART_REASON "Причина за рестарта"
#define D_RESTORE "възстановяване"
#define D_RETAINED "запазено"
#define D_RULE "Правило"
#define D_SAVE "Запис"
#define D_SENSOR "Датчик"
#define D_SSID "SSId"
#define D_START "Старт"
#define D_STD_TIME "STD"
#define D_STOP "Стоп"
#define D_SUBNET_MASK "Маска на подмрежата"
#define D_SUBSCRIBE_TO "Записване за"
#define D_SUCCESSFUL "Успешно"
#define D_SUNRISE "Изгрев"
#define D_SUNSET "Залез"
#define D_TEMPERATURE "Температура"
#define D_TO "към"
#define D_TOGGLE "Превключване"
#define D_TOPIC "Топик"
#define D_TRANSMIT "Предаване"
#define D_TRUE "Вярно"
#define D_TVOC "TVOC"
#define D_UPGRADE "Обновяване"
#define D_UPLOAD "Зареждане"
#define D_UPTIME "Време от стартирането"
#define D_USER "Потребител"
#define D_UTC_TIME "UTC"
#define D_UV_INDEX "UV индекс"
#define D_UV_LEVEL "Ниво на ултравиолетово излъчване"
#define D_VERSION "Версия"
#define D_VOLTAGE "Напрежение"
#define D_WARMLIGHT "Топла"
#define D_WEB_SERVER "Уеб сървър"

// sonoff.ino
#define D_WARNING_MINIMAL_VERSION "ПРЕДУПРЕЖДЕНИЕ Тази версия не поддържа постоянни настройки"
#define D_LEVEL_10 "ниво 1-0"
#define D_LEVEL_01 "ниво 0-1"
#define D_SERIAL_LOGGING_DISABLED "Серийния логинг изключен"
#define D_SYSLOG_LOGGING_REENABLED "Системния логинг активиран"

#define D_SET_BAUDRATE_TO "Задаване скорост на предаване (Baudrate)"
#define D_RECEIVED_TOPIC "Получен топик"
#define D_DATA_SIZE "Размер на данните"
#define D_ANALOG_INPUT "Аналогов вход"

// support.ino
#define D_OSWATCH "osWatch"
#define D_BLOCKED_LOOP "Блокиран цикъл"
#define D_WPS_FAILED_WITH_STATUS "WPS конфигурацията е НЕУСПЕШНА със статус"
#define D_ACTIVE_FOR_3_MINUTES "активно в течение на 3 минути"
#define D_FAILED_TO_START "неуспешно стартиране"
#define D_PATCH_ISSUE_2186 "Проблем с патч 2186"
#define D_CONNECTING_TO_AP "Свързване към точка за достъп"
#define D_IN_MODE "в режим"
#define D_CONNECT_FAILED_NO_IP_ADDRESS "Грешка при свързването, не е получен IP адрес"
#define D_CONNECT_FAILED_AP_NOT_REACHED "Грешка при свързването, точката за достъп е недостижима"
#define D_CONNECT_FAILED_WRONG_PASSWORD "Грешка при свързването, грешна парола към точката за достъп"
#define D_CONNECT_FAILED_AP_TIMEOUT "Грешка при свързването, превишено време за изчакване"
#define D_ATTEMPTING_CONNECTION "Опитва свързване..."
#define D_CHECKING_CONNECTION "Проверка на свързването..."
#define D_QUERY_DONE "Запитването е изпълнено. Намерена е услуга MQTT"
#define D_MQTT_SERVICE_FOUND "MQTT услуга е намерена на"
#define D_FOUND_AT "намерена в"
#define D_SYSLOG_HOST_NOT_FOUND "Хостът на системния лог не е намерен"

// settings.ino
#define D_SAVED_TO_FLASH_AT "Запазено във флаш паметта на"
#define D_LOADED_FROM_FLASH_AT "Заредено от флаш паметта от"
#define D_USE_DEFAULTS "Използване на параметри по подразбиране"
#define D_ERASED_SECTOR "Изтрит сектор"

// xdrv_02_webserver.ino
#define D_MINIMAL_FIRMWARE_PLEASE_UPGRADE "Минимален фърмуеър - моля надградете го"
#define D_WEBSERVER_ACTIVE_ON "Уеб сървърът е активен на"
#define D_WITH_IP_ADDRESS "с IP адрес"
#define D_WEBSERVER_STOPPED "Уеб сървърът е спрян"
#define D_FILE_NOT_FOUND "Файлът не е намерен"
#define D_REDIRECTED "Пренасочено към адаптивния портал"
#define D_WIFIMANAGER_SET_ACCESSPOINT_AND_STATION "Wifi мениджърът настройва точка за достъп и запомня станцията"
#define D_WIFIMANAGER_SET_ACCESSPOINT "Wifi мениджърът настрои точката за достъп"
#define D_TRYING_TO_CONNECT "Опит за свързване на устройството към мрежата"

#define D_RESTART_IN "Рестарт след"
#define D_SECONDS "секунди"
#define D_DEVICE_WILL_RESTART "Устройството ще се рестартира след няколко секунди"
#define D_BUTTON_TOGGLE "Превключване"
#define D_CONFIGURATION "Конфигурация"
#define D_INFORMATION "Информация"
#define D_FIRMWARE_UPGRADE "Обновяване на фърмуеъра"
#define D_CONSOLE "Конзола"
#define D_CONFIRM_RESTART "Подтвърдете рестартирането"

#define D_CONFIGURE_MODULE "Конфигурация на модула"
#define D_CONFIGURE_WIFI "Конфигурация на WiFi"
#define D_CONFIGURE_MQTT "Конфигурация на MQTT"
#define D_CONFIGURE_DOMOTICZ "Конфигурация на Domoticz"
#define D_CONFIGURE_LOGGING "Конфигурация на логинга"
#define D_CONFIGURE_OTHER "Драги конфигурации"
#define D_CONFIRM_RESET_CONFIGURATION "Потвърдете изчистването"
#define D_RESET_CONFIGURATION "Изчистване на конфигурацията"
#define D_BACKUP_CONFIGURATION "Запазване на конфигурацията"
#define D_RESTORE_CONFIGURATION "Възстановяване на конфигурацията"
#define D_MAIN_MENU "Основно меню"

#define D_MODULE_PARAMETERS "Параметри на модула"
#define D_MODULE_TYPE "Тип на модула"
#define D_GPIO "GPIO"
#define D_SERIAL_IN "Сериен вход"
#define D_SERIAL_OUT "Сериен изход"

#define D_WIFI_PARAMETERS "Wifi параметри"
#define D_SCAN_FOR_WIFI_NETWORKS "Сканиране за безжични мрежи"
#define D_SCAN_DONE "Сканирането приключи"
#define D_NO_NETWORKS_FOUND "Не бяха открити мрежи"
#define D_REFRESH_TO_SCAN_AGAIN "Обновяване за повторно сканиране"
#define D_DUPLICATE_ACCESSPOINT "Дублиране на точката за достъп (AP)"
#define D_SKIPPING_LOW_QUALITY "Пропускане поради лошо качество"
#define D_RSSI "RSSI"
#define D_WEP "WEP"
#define D_WPA_PSK "WPA PSK"
#define D_WPA2_PSK "WPA2 PSK"
#define D_AP1_SSID "AP1 SSId"
#define D_AP1_PASSWORD "AP1 Парола"
#define D_AP2_SSID "AP2 SSId"
#define D_AP2_PASSWORD "AP2 Парола"

#define D_MQTT_PARAMETERS "Параметри на MQTT"
#define D_CLIENT "Клиент"
#define D_FULL_TOPIC "Пълен топик"

#define D_LOGGING_PARAMETERS "Параметри на логинга"
#define D_SERIAL_LOG_LEVEL "Степен на серийния лог"
#define D_WEB_LOG_LEVEL "Степен на Уеб лога"
#define D_SYS_LOG_LEVEL "Степен на системния лог"
#define D_MORE_DEBUG "Още дебъгване"
#define D_SYSLOG_HOST "Хост на системния лог"
#define D_SYSLOG_PORT "Порт на системния лог"
#define D_TELEMETRY_PERIOD "Период на телеметрия"

#define D_OTHER_PARAMETERS "Други параметри"
#define D_WEB_ADMIN_PASSWORD "Парола на уеб администратора"
#define D_MQTT_ENABLE "Активиране на MQTT"
#define D_FRIENDLY_NAME "Приятелско име"
#define D_BELKIN_WEMO "Belkin WeMo"
#define D_HUE_BRIDGE "Hue Bridge"
#define D_SINGLE_DEVICE "Единично"
#define D_MULTI_DEVICE "Мулти"

#define D_SAVE_CONFIGURATION "Запазване на конфигурацията"
#define D_CONFIGURATION_SAVED "Конфигурацията е запазена"
#define D_CONFIGURATION_RESET "Конфигурацията е изчистена"

#define D_PROGRAM_VERSION "Версия на програмата"
#define D_BUILD_DATE_AND_TIME "Дата и час на компилацията"
#define D_CORE_AND_SDK_VERSION "Версия на Core/SDK"
#define D_FLASH_WRITE_COUNT "Брой на записите във флаш паметта"
#define D_MAC_ADDRESS "MAC адрес"
#define D_MQTT_HOST "MQTT хост"
#define D_MQTT_PORT "MQTT порт"
#define D_MQTT_CLIENT "MQTT ID на клиент"
#define D_MQTT_USER "MQTT потребител"
#define D_MQTT_TOPIC "MQTT топик"
#define D_MQTT_GROUP_TOPIC "MQTT групов топик"
#define D_MQTT_FULL_TOPIC "MQTT пълен топик"
#define D_MDNS_DISCOVERY "mDNS откриване"
#define D_MDNS_ADVERTISE "mDNS транслация"
#define D_ESP_CHIP_ID "ID на ESP чипа"
#define D_FLASH_CHIP_ID "ID на чипа на флаш паметта"
#define D_FLASH_CHIP_SIZE "Размер на флаш паметта"
#define D_FREE_PROGRAM_SPACE "Свободно пространство за програми"

#define D_UPGRADE_BY_WEBSERVER "Обновяване чрез уеб сървър"
#define D_OTA_URL "OTA Url"
#define D_START_UPGRADE "Започване на обновяване"
#define D_UPGRADE_BY_FILE_UPLOAD "Обновяване чрез зареждане на файл"
#define D_UPLOAD_STARTED "Зареждането започна"
#define D_UPGRADE_STARTED "Обновяването започна"
#define D_UPLOAD_DONE "Зареждането завърши"
#define D_UPLOAD_ERR_1 "Не е избран файл"
#define D_UPLOAD_ERR_2 "Недостатъчно свободно място"
#define D_UPLOAD_ERR_3 "Magic байтът не е 0xE9"
#define D_UPLOAD_ERR_4 "Размерът на програмата е по-голям от реалния размер на флаш паметта"
#define D_UPLOAD_ERR_5 "Грешка при зареждането в буфера"
#define D_UPLOAD_ERR_6 "Грешка при зареждането. Включено е ниво 3 на лога"
#define D_UPLOAD_ERR_7 "Зареждането е прекъснато"
#define D_UPLOAD_ERR_8 "Файлът е невалиден"
#define D_UPLOAD_ERR_9 "Файлът е прекалено голям"
#define D_UPLOAD_ERR_10 "Грешка при инициализация на RF чипа"
#define D_UPLOAD_ERR_11 "Грешка при изтриване на RF чипа"
#define D_UPLOAD_ERR_12 "Грешка при записване в RF чипа"
#define D_UPLOAD_ERR_13 "Грешка при декодиране на RF фирмуера"
#define D_UPLOAD_ERROR_CODE "Код на грешка при зареждането"

#define D_ENTER_COMMAND "Въвеждане на команда"
#define D_ENABLE_WEBLOG_FOR_RESPONSE "Включете ниво 2 на лога, ако очаквате отговор"
#define D_NEED_USER_AND_PASSWORD "Очаква user=<username>&password=<password>"

// xdrv_01_mqtt.ino
#define D_FINGERPRINT "Проверка на TLS отпечатък..."
#define D_TLS_CONNECT_FAILED_TO "Неуспешно TLS свързване към"
#define D_RETRY_IN "Повторно след"
#define D_VERIFIED "Проверен отпечтък"
#define D_INSECURE "Нешифрована връзка, недействителен отпечатък"
#define D_CONNECT_FAILED_TO "Грешка при свързването към"

// xplg_wemohue.ino
#define D_MULTICAST_DISABLED "Multicast е изключен"
#define D_MULTICAST_REJOINED "Multicast е повторно съединен"
#define D_MULTICAST_JOIN_FAILED "Multicast грешка при присъединяването"
#define D_FAILED_TO_SEND_RESPONSE "Не се получи изпращането на отговор"

#define D_WEMO "WeMo"
#define D_WEMO_BASIC_EVENT "WeMo главно събитие"
#define D_WEMO_EVENT_SERVICE "WeMo услуга за събитията"
#define D_WEMO_META_SERVICE "WeMo мета-услуга"
#define D_WEMO_SETUP "WeMo настройка"
#define D_RESPONSE_SENT "Отговорът е изпратен"

#define D_HUE "Hue"
#define D_HUE_BRIDGE_SETUP "Настройка на Hue bridge"
#define D_HUE_API_NOT_IMPLEMENTED "Hue API не е внедрено"
#define D_HUE_API "Hue API"
#define D_HUE_POST_ARGS "Hue POST аргументи"
#define D_3_RESPONSE_PACKETS_SENT "Изпратени са 3 пакета за отговор"

// xdrv_07_domoticz.ino
#define D_DOMOTICZ_PARAMETERS "Domoticz параметри"
#define D_DOMOTICZ_IDX "Idx"
#define D_DOMOTICZ_KEY_IDX "Key idx"
#define D_DOMOTICZ_SWITCH_IDX "Switch idx"
#define D_DOMOTICZ_SENSOR_IDX "Sensor idx"
  #define D_DOMOTICZ_TEMP "Temp"
  #define D_DOMOTICZ_TEMP_HUM "Temp,Hum"
  #define D_DOMOTICZ_TEMP_HUM_BARO "Temp,Hum,Baro"
  #define D_DOMOTICZ_POWER_ENERGY "Power,Energy"
  #define D_DOMOTICZ_ILLUMINANCE "Illuminance"
  #define D_DOMOTICZ_COUNT "Count/PM1"
  #define D_DOMOTICZ_VOLTAGE "Voltage/PM2,5"
  #define D_DOMOTICZ_CURRENT "Current/PM10"
  #define D_DOMOTICZ_AIRQUALITY "AirQuality"
#define D_DOMOTICZ_UPDATE_TIMER "Update timer"

// xdrv_09_timers.ino
#define D_CONFIGURE_TIMER "Конфигуриране на таймер"
#define D_TIMER_PARAMETERS "Параметри на таймера"
#define D_TIMER_ARM "Arm"
#define D_TIMER_TIME "Време"
#define D_TIMER_DAYS "Дни"
#define D_TIMER_REPEAT "Повтори"
#define D_TIMER_OUTPUT "Изход"
#define D_TIMER_ACTION "Действие"

// xdrv_10_knx.ino
#define D_CONFIGURE_KNX "Конфигуриране на KNX"
#define D_KNX_PARAMETERS "KNX параметри"
#define D_KNX_GENERAL_CONFIG "Основни"
#define D_KNX_PHYSICAL_ADDRESS "Физически адрес"
#define D_KNX_PHYSICAL_ADDRESS_NOTE "( Трябва да е уникален в KNX мрежата )"
#define D_KNX_ENABLE "Активиране на KNX"
#define D_KNX_GROUP_ADDRESS_TO_WRITE "Групови адреси за изпращане на данни"
#define D_ADD "Добаване"
#define D_DELETE "Изтриване"
#define D_REPLY "Отговор"
#define D_KNX_GROUP_ADDRESS_TO_READ "Групови адреси за получаване на данни"
#define D_LOG_KNX "KNX: "
#define D_RECEIVED_FROM "Получен от"
#define D_KNX_COMMAND_WRITE "Писане"
#define D_KNX_COMMAND_READ "Четене"
#define D_KNX_COMMAND_OTHER "Друго"
#define D_SENT_TO "изпратен до"
#define D_KNX_WARNING "Груповият адрес ( 0 / 0 / 0 ) е резервиран и не може да бъде използван."
#define D_KNX_ENHANCEMENT "Подобрена комуникация"
#define D_KNX_TX_SLOT "KNX TX"
#define D_KNX_RX_SLOT "KNX RX"

// xdrv_03_energy.ino
#define D_ENERGY_TODAY "Използвана енергия днес"
#define D_ENERGY_YESTERDAY "Използвана енергия вчера"
#define D_ENERGY_TOTAL "Използвана енергия общо"

// xsns_05_ds18b20.ino
#define D_SENSOR_BUSY "Датчикът DS18x20 е зает"
#define D_SENSOR_CRC_ERROR "Датчик DS18x20 - грешка CRC"
#define D_SENSORS_FOUND "Намерен е датчик DS18x20"

// xsns_06_dht.ino
#define D_TIMEOUT_WAITING_FOR "Изтекло време за очакване на"
#define D_START_SIGNAL_LOW "Нисък стартов сигнал"
#define D_START_SIGNAL_HIGH "Висок стартов сигнал"
#define D_PULSE "Импулс"
#define D_CHECKSUM_FAILURE "Грешка в контролната сума"

// xsns_07_sht1x.ino
#define D_SENSOR_DID_NOT_ACK_COMMAND "Датчикът не прие команда ACK"
#define D_SHT1X_FOUND "Намерен е SHT1X"

// xsns_18_pms5003.ino
#define D_STANDARD_CONCENTRATION "CF-1 PM"     // Standard Particle CF-1 Particle Matter
#define D_ENVIRONMENTAL_CONCENTRATION "PM"     // Environmetal Particle Matter
#define D_PARTICALS_BEYOND "Частици"

// sonoff_template.h
#define D_SENSOR_NONE     "Няма"
#define D_SENSOR_DHT11    "DHT11"
#define D_SENSOR_AM2301   "AM2301"
#define D_SENSOR_SI7021   "SI7021"
#define D_SENSOR_DS18X20  "DS18x20"
#define D_SENSOR_I2C_SCL  "I2C SCL"
#define D_SENSOR_I2C_SDA  "I2C SDA"
#define D_SENSOR_WS2812   "WS2812"
#define D_SENSOR_IRSEND   "IRsend"
#define D_SENSOR_SWITCH   "Ключ"   // Suffix "1"
#define D_SENSOR_BUTTON   "Бутон"   // Suffix "1"
#define D_SENSOR_RELAY    "Реле"    // Suffix "1i"
#define D_SENSOR_LED      "Led"      // Suffix "1i"
#define D_SENSOR_PWM      "PWM"      // Suffix "1"
#define D_SENSOR_COUNTER  "Брояч"  // Suffix "1"
#define D_SENSOR_IRRECV   "IRrecv"
#define D_SENSOR_MHZ_RX   "MHZ Rx"
#define D_SENSOR_MHZ_TX   "MHZ Tx"
#define D_SENSOR_PZEM_RX  "PZEM Rx"
#define D_SENSOR_PZEM_TX  "PZEM Tx"
#define D_SENSOR_SAIR_RX  "SAir Rx"
#define D_SENSOR_SAIR_TX  "SAir Tx"
#define D_SENSOR_SPI_CS   "SPI CS"
#define D_SENSOR_SPI_DC   "SPI DC"
#define D_SENSOR_BACKLIGHT "Подсветка"
#define D_SENSOR_PMS5003  "PMS5003"
#define D_SENSOR_SDS0X1   "SDS0X1"
#define D_SENSOR_SBR_RX   "SerBr Rx"
#define D_SENSOR_SBR_TX   "SerBr Tx"
#define D_SENSOR_SR04_TRIG "SR04 Tri"
#define D_SENSOR_SR04_ECHO "SR04 Ech"
#define D_SENSOR_SDM120_TX "SDM120 Tx"
#define D_SENSOR_SDM120_RX "SDM120 Rx"
#define D_SENSOR_SDM630_TX "SDM630 Tx"
#define D_SENSOR_SDM630_RX "SDM630 Rx"
#define D_SENSOR_TM1638_CLK "TM16 CLK"
#define D_SENSOR_TM1638_DIO "TM16 DIO"
#define D_SENSOR_TM1638_STB "TM16 STB"

// Units
#define D_UNIT_AMPERE "A"
#define D_UNIT_CENTIMETER "cm"
#define D_UNIT_HERTZ "Hz"
#define D_UNIT_HOUR "h"
#define D_UNIT_KILOOHM "kΩ"
#define D_UNIT_KILOWATTHOUR "kWh"
#define D_UNIT_LUX "lx"
#define D_UNIT_MICROGRAM_PER_CUBIC_METER "µg/m3"
#define D_UNIT_MICROMETER "µm"
#define D_UNIT_MICROSECOND "µs"
#define D_UNIT_MILLIAMPERE "mA"
#define D_UNIT_MILLISECOND "ms"
#define D_UNIT_MINUTE "min"
#define D_UNIT_PARTS_PER_BILLION "ppb"
#define D_UNIT_PARTS_PER_DECILITER "ppd"
#define D_UNIT_PARTS_PER_MILLION "ppm"
#define D_UNIT_PRESSURE "hPa"
#define D_UNIT_SECOND "s"
#define D_UNIT_SECTORS "сектори"
#define D_UNIT_VA "VA"
#define D_UNIT_VAR "VAr"
#define D_UNIT_VOLT "V"
#define D_UNIT_WATT "W"
#define D_UNIT_WATTHOUR "Wh"

// Log message prefix
#define D_LOG_APPLICATION "APP: "  // Application
#define D_LOG_BRIDGE "BRG: "       // Bridge
#define D_LOG_CONFIG "CFG: "       // Settings
#define D_LOG_COMMAND "CMD: "      // Command
#define D_LOG_DEBUG "DBG: "        // Debug
#define D_LOG_DHT "DHT: "          // DHT sensor
#define D_LOG_DOMOTICZ "DOM: "     // Domoticz
#define D_LOG_DSB "DSB: "          // DS18xB20 sensor
#define D_LOG_HTTP "HTP: "         // HTTP webserver
#define D_LOG_I2C "I2C: "          // I2C
#define D_LOG_IRR "IRR: "          // Infra Red Received
#define D_LOG_LOG "LOG: "          // Logging
#define D_LOG_MODULE "MOD: "       // Module
#define D_LOG_MDNS "DNS: "         // mDNS
#define D_LOG_MQTT "MQT: "         // MQTT
#define D_LOG_OTHER "OTH: "        // Other
#define D_LOG_RESULT "RSL: "       // Result
#define D_LOG_RFR "RFR: "          // RF Received
#define D_LOG_SERIAL "SER: "       // Serial
#define D_LOG_SHT1 "SHT: "         // SHT1x sensor
#define D_LOG_UPLOAD "UPL: "       // Upload
#define D_LOG_UPNP "UPP: "         // UPnP
#define D_LOG_WIFI "WIF: "         // Wifi

#endif  // _LANGUAGE_BG_BG_H_
